import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dboosting',
  templateUrl: './dboosting.component.html',
  styleUrls: ['./dboosting.component.scss']
})
export class DboostingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
