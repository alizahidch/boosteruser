import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dqueue',
  templateUrl: './dqueue.component.html',
  styleUrls: ['./dqueue.component.scss']
})
export class DqueueComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
